# Dream Craft Events – Android app

Wraps https://dreamcrafteventmanagment.github.io/dreamcraftevents/ in a full-screen app.

- WhatsApp, call, email, Google Maps and Instagram links open in their own apps
- Offline screen with a Retry button
- Dark/gold theme matching the website, gold star launcher icon
- Back button navigates the website, then exits
- Any change you make to the website shows up in the app automatically (no rebuild needed)

## Option A – Build the APK online (no installs)

1. Create a new repository on github.com (for example `dreamcraft-app`).
2. Upload everything in this folder to it. Make sure the hidden folder
   `.github/workflows/build-apk.yml` is included (if the upload skips it, use
   Add file > Create new file and type `.github/workflows/build-apk.yml`,
   then paste the file contents).
3. Open the **Actions** tab > **Build APK** > **Run workflow** (it also runs on every push).
4. When it finishes (about 3 minutes), open the run and download the
   **DreamCraftEvents-apk** artifact. Unzip it to get `app-debug.apk`.
5. Copy the APK to an Android phone and open it. Allow "Install unknown apps" when asked.

## Option B – Android Studio

1. Install Android Studio and choose File > Open > this folder.
2. Wait for the Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The file is in `app/build/outputs/apk/debug/app-debug.apk`.

## Customising

- Website address: `HOME` and `HOST` at the top of `MainActivity.java`
- App name: `app/src/main/res/values/strings.xml`
- Icon: in Android Studio, right-click `res` > New > Image Asset and pick your `logo.png`
- Colours: `app/src/main/res/values/colors.xml`

## Publishing on Google Play

The debug APK is fine for installing directly on phones. Google Play needs a
signed release bundle (AAB) and a developer account, so ask for that as a
separate step.
